from selenium import webdriver
import time
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from flask import Flask, render_template, request
from selenium.webdriver.support.ui import Select

app = Flask(__name__)

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver-win64\chromedriver-win64\chromedriver.exe"))


@app.route('/')
def login():
    return render_template("index.html")


@app.route('/process_form', methods=['post'])
def form():
    email = request.form.get('Email')
    password = request.form.get('password')
    campus = request.form.get('campus')
    print(email)
    print(password)
    print(campus)
    driver.get("https://cms.bahria.edu.pk/Logins/Student/Login.aspx")
    driver.implicitly_wait(5)
    enter_email = driver.find_element(By.XPATH, "//input[@ name='ctl00$BodyPH$tbEnrollment']")
    enter_email.clear()
    enter_email.send_keys(email)
    enter_password = driver.find_element(By.XPATH, "//input[@ placeholder='Password']")
    enter_password.clear()
    enter_password.send_keys(password)
    enter_campus = driver.find_element(By.XPATH, "//*[@id='BodyPH_ddlInstituteID']")
    enter_campus.send_keys(campus)
    driver.find_element(By.XPATH, "//a[@ data-validationgroup='Login']").click()
    driver.maximize_window()
    time.sleep(5)
    return render_template("LMS.html")


@app.route("/process_form1", methods=["post"])
def options():
    select = request.form.get('option')
    select1 = request.form.get('secondOption')
    select3 = request.form.get('text')
    select2 = request.form.get('option4')
    print(select)

    if select == "Profile Information":
        driver.find_element(By.XPATH, "//a[normalize-space()='Profile Information']").click()
        rows = len(driver.find_elements(By.XPATH, '//*[@id="pageContent"]/div[3]/table/tbody/tr'))
        cols = len(driver.find_elements(By.XPATH, '//*[@id="pageContent"]/div[3]/table/tbody/tr[1]/td'))
        theader = len(driver.find_elements(By.XPATH, "//*[@id='pageContent']/div[3]/table/tbody/tr[1]/th"))
        alert = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]").text
        print(alert)
        table_values = []
        row_values = []
        for r in range(1, 7):
            for c in range(1, 3):
                value = driver.find_element(By.XPATH,
                                            "//*[@id='pageContent']/div[3]/table/tbody/tr[" + str(r) + "]/th[" + str(
                                                c) + "]").text

                value1 = driver.find_element(By.XPATH,
                                             "//*[@id='pageContent']/div[3]/table/tbody/tr[" + str(r) + "]/td[" + str(
                                                 c) + "]").text
                print(value, value1)

            print("\n")
            table_values.append(row_values)
        for r1 in range(7, 9):
            value3 = driver.find_element(By.XPATH,
                                         "//*[@id='pageContent']/div[3]/table/tbody/tr[" + str(r1) + "]/th").text
            value4 = driver.find_element(By.XPATH,
                                         "//*[@id='pageContent']/div[3]/table/tbody/tr[" + str(r1) + "]/td").text
            print(value3, value4)
            upemail = ""
            if upemail == "Update Email":
                driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/table/tbody/tr[6]/td[1]/small/a").click()
                changeemail = driver.find_element(By.XPATH, "//*[@id='BodyPH_tbPersonalEmail']").clear()
                changeemail.send_keys("add krni ha flask app sa read kar ka")
                driver.find_element(By.XPATH, "//*[@id='BodyPH_btnUpdatePersonalEmail']").click()
    if select == "Course Registration":
        driver.find_element(By.XPATH, "//*[@id='sideMenuList']/a[2]").click()
        if select1 == "Registered Courses":
            driver.find_element(By.XPATH, "//a[normalize-space()='Registered Courses']").click()
            driver.find_element(By.XPATH, "//*[@id='pageHeading']").click()
            for th in range(1, 11):
                table = driver.find_element(By.XPATH,
                                            "//*[@id='pageContent']/div[3]/div[2]/table[1]/thead/tr/th[1]").text
                print(table)
            for r1 in range(1, 8):
                for c1 in range(1, 11):
                    data = driver.find_element(By.XPATH,
                                               "//*[@id='pageContent']/div[3]/div[2]/table[1]/tbody/tr[" + str(
                                                   r1) + "]/td[" + str(c1) + "]").text
                    print(data)
            for th1 in range(1, 11):
                table1 = driver.find_element(By.XPATH,
                                             "//*[@id='pageContent']/div[3]/div[2]/table[2]/thead/tr/th[1]").text
                print(table1)
            for r2 in range(1, 8):
                for c2 in range(1, 11):
                    data1 = driver.find_element(By.XPATH,
                                                "//*[@id='pageContent']/div[3]/div[2]/table[2]/tbody/tr[" + str(
                                                    r2) + "]/td[" + str(c2) + "]").text
                    print(data1)
        if select1 == "Register Regular Courses":
            driver.find_element(By.XPATH, "//a[normalize-space()='Register Regular Courses']").click()
            d1 = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
            print(d1)
            d2 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]/table/thead/tr[1]/th[2]").text
            d3 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]/table/thead/tr[1]/th[3]").text
            print(d2, d3)
            for c1 in range(1, 10):
                data = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]/table/thead/tr[2]/th[" + str(
                    c1) + "]").text
                print(data)
            for r1 in range(1, 8):
                for c1 in range(1, 11):
                    data1 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]/table/tbody/tr[" + str(
                        r1) + "]/td[" + str(c1) + "]").text
                    print(data1)
        if select1 == "View Offered Courses":
            driver.find_element(By.XPATH, "//a[normalize-space()='View Offered Courses']").click()

            t1 = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
            print(t1)
            t2 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[2]").text
        if select1 == "Credits Transfer":
            driver.find_element(By.XPATH, "//a[normalize-space()='Credits Transfer']").click()

            t1 = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
            print(t1)
            t2 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[2]").text
    if select == "Time Table":
        driver.find_element(By.XPATH, "//a[normalize-space()='Time Table']").click()
        t1 = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(t1)
        t2 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[2]").text
        print(t2)
    if select == "Attendence":
        driver.find_element(By.XPATH, "//a[normalize-space()='Attendance']").click()
        attendance = driver.find_element(By.XPATH, "//*[@id='pageTitle_h1']").text
        print(attendance)
        for tr in range(1, 14):
            theading = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]/table/thead/tr/th[" + str(
                tr) + "]").text
            print(theading, "\t")
        for tbr in range(1, 8):
            for tbc in range(1, 14):
                adata = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]/table/tbody/tr[" + str(
                    tbr) + "]/td[" + str(tbc) + "]").text
                print(adata, "\t")
    if select == "Provisional Result":

        #   get input from semester no

        driver.find_element(By.XPATH, "//a[normalize-space()='Provisional Result']").click()
        heading = driver.find_element(By.XPATH, "//h1[@id='pageTitle_h1']").text
        for r in range(1, 5):
            for c in range(1, 3):
                prsthb = driver.find_element(By.XPATH,
                                             "//*[@id='pageContent']/div[3]/div[2]/table/tbody/tr[" + str(
                                                 r) + "]/th[" + str(c) + "]").text
                prsth = driver.find_element(By.XPATH,
                                            "//*[@id='pageContent']/div[3]/div[2]/table/tbody/tr[" + str(
                                                r) + "]/td[" + str(c) + "]").text
                print(prsthb, prsth)
            sem = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/table[1]/caption").text
            print(sem)
            for th in range(1, 9):
                pr = driver.find_element(By.XPATH,
                                         "//*[@id='pageContent']/div[3]/table[1]/thead/tr/th[" + str(th) + "]").text
                print(pr)
            for r1 in range(1, 8):
                for c1 in range(1, 9):
                    result = driver.find_element(By.XPATH,
                                                 "//*[@id='pageContent']/div[3]/table[1]/tbody/tr[" + str(
                                                     r1) + "]/td[" + str(c1) + "]").text
                    print(result)
            gpa = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/table[1]/tbody/tr[8]/td").text
            print(gpa)
            sem1 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/table[2]/caption").text
            print(sem1)
            for th1 in range(1, 9):
                pr1 = driver.find_element(By.XPATH,
                                          "//*[@id='pageContent']/div[3]/table[2]/thead/tr/th[" + str(th) + "]").text
                print(pr1)
            for r2 in range(1, 8):
                for c2 in range(1, 9):
                    result = driver.find_element(By.XPATH,
                                                 "//*[@id='pageContent']/div[3]/table[2]/tbody/tr[" + str(
                                                     r2) + "]/td[" + str(c2) + "]").text
                    print(result)
    if select == "Quality Assurance Surveys":
        driver.find_element(By.XPATH, "//a[normalize-space()='Quality Assurance Surveys']").click()
        t3 = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(t3)
    if select == "Fee Challans":
        driver.find_element(By.XPATH, "//a[normalize-space()='Fee Challans']").click()
        heading = driver.find_element(By.XPATH, "//*[@id='pageTitle_h1']").text
        print(heading)
        for th in range(1, 10):
            heading = driver.find_element(By.XPATH,
                                          "//*[@id='pageContent']/div[3]/table[2]/thead/tr/th[" + str(th) + "]").text
            print(heading)
        for r3 in range(1, 2):
            for c3 in range(1, 10):
                fdata = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/table[2]/tbody/tr[" + str(
                    r3) + "]/td[" + str(c3) + "]").text
                print(fdata)
    if select == "Exam Seating Plan":
        driver.find_element(By.XPATH, "//a[normalize-space()='Exam Seating Plan']").click()
        t1 = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(t1)
        t2 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[2]").text
        print(t2)
    if select == "Community Service":
        driver.find_element(By.XPATH, "//a[normalize-space()='Community Service']").click()
        t1 = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(t1)
        t2 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[2]").text
        print(t2)
    if select == "Academic Documents":
        driver.find_element(By.XPATH, "//a[normalize-space()='Academic Documents']").click()
        head = driver.find_element(By.XPATH, "//*[@id='pageTitle_h1']").text
        print(head)
        head1 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]/div").text
        print(head1)
        for r1 in range(1, 9):
            th = driver.find_element(By.XPATH,
                                     "//*[@id='pageContent']/div[3]/div[2]/table/thead/tr/th[" + str(r1) + "]").text
            print(th)
        for r2 in range(1, 3):
            for c2 in range(1, 9):
                data = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]/table/tbody/tr[" + str(
                    r2) + "]/td[" + str(c2) + "]").text
                print(data)
        two = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[3]/div[1]").text
        print(two)
        st1 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[3]/table[1]/tbody/tr[1]/th[1]").text
        st2 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[3]/table[1]/tbody/tr[1]/td[1]").text
        st3 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[3]/table[1]/tbody/tr[1]/th[2]").text
        st4 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[3]/table[1]/tbody/tr[1]/td[2]").text
        st5 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[3]/table[1]/tbody/tr[2]/th").text
        st6 = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[3]/table[1]/tbody/tr[2]/td").text
        print(st1, st2, st3, st4, st5, st6)
        for i in range(1, 9):
            head = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[3]/table[2]/thead/tr/th[1]").text
            print(head)
        for r1 in range(1, 4):
            for c1 in range(1, 9):
                three = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[3]/table[2]/tbody/tr[" + str(
                    r1) + "]/td[" + str(c1) + "]").text
                print(three)
    if select == "Official Documents":
        driver.find_element(By.XPATH, "//a[normalize-space()='Official Documents']").click()
        ofd = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(ofd)
        for r1 in range(1, 5):
            head = driver.find_element(By.XPATH,
                                       "//*[@id='pageContent']/div[3]/div[2]/table/thead/tr/th[" + str(r1) + "]").text
            print(head)
        for r2 in range(1, 30):
            for c2 in range(1, 5):
                data = driver.find_element(By.XPATH,
                                           "//*[@id='pageContent']/div[3]/div[2]/table/tbody/tr[" + str(
                                               r2) + "]/td[" + str(c2) + "]").text
                print(data)

        ### DISPLAY THEN GET INPUT FROM USER WHICH ONE YOU NEED TO DOWNLOAD
    if select == "Available Scholarship":
        driver.find_element(By.XPATH, "//a[normalize-space()='Available Scholarship']").click()
        fas = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(fas)
        for r3 in range(1, 8):
            data = driver.find_element(By.XPATH, "//*[@id='pageContent']/div[3]/div[2]/table/thead/tr/th[1]").text
            print(data)
    if select == "Microsoft Email Account":
        driver.find_element(By.XPATH, "//a[normalize-space()='Microsoft Email Account']").click()
        mea = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(mea)
        for r4 in range(1, 4):
            for c4 in range(1, 3):
                data = driver.find_element(By.XPATH,
                                           "//*[@id='pageContent']/div[3]/table/tbody/tr[" + str(r4) + "]/th[" + str(
                                               c4) + "]").text
                print(data)
                data1 = driver.find_element(By.XPATH,
                                            "//*[@id='pageContent']/div[3]/table/tbody/tr[" + str(r4) + "]/td[" + str(
                                                c4) + "]").text
                print(data1)
        red = driver.find_element(By.XPATH, "//*[@id='BodyPH_panel']/div[1]").text
        print(red)
        info = driver.find_element(By.XPATH, "//*[@id='BodyPH_panel']").text
        print(info)
    if select == "Forms":
        driver.find_element(By.XPATH, "//a[normalize-space()='Forms']").click()
        head = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(head)
        record = driver.find_element(By.XPATH, "//*[@id='BodyPH_gvForms']/tbody/tr/td").text
        print(record)
    if select == "Go To LMS":
        href = driver.find_element(By.XPATH, "//*[@id='sideMenuList']/a[15]").get_attribute('href')
        driver.get(href)
    if select == "UnderTakings":
        driver.find_element(By.XPATH, "//a[normalize-space()='UnderTakings']").click()
        data = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(data)
        for r4 in range(1, 4):
            t1 = driver.find_element(By.XPATH, "//*[@id='BodyPH_gvUnderTakings']/thead/tr/th[" + str(r4) + "]").text
            print(t1)
            t2 = driver.find_element(By.XPATH, "//*[@id='BodyPH_gvUnderTakings']/tbody/tr/td[" + str(r4) + "]").text
            print(t2)
    if select == "Virtual Suggestion Box":
        driver.find_element(By.XPATH, "//*[@id='sideMenuList']/a[17]").click()
        data = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(data)
    if select == "Thesis Dashboard":
        driver.find_element(By.XPATH, "//a[normalize-space()='Thesis Dashboard']").click()
        data = driver.find_element(By.XPATH, "//*[@id='pageHeading']").text
        print(data)

    if select == "Convocation Registration":
        driver.find_element(By.XPATH, "//a[normalize-space()='Convocation Registration']").click()
        t1 = driver.find_element(By.XPATH, "//h1[@id='pageTitle_h1']").text
        print(t1)
    return render_template("next.html")


@app.route("/newtry", methods=['post'])
def process():
    select2 = request.form.get('option4')
    print(select2)
    lectnote = request.form.get('lectureNotesInput')
    print(lectnote)
    assesment = request.form.get('lectureNotesInput1')
    print(assesment)
    assno=request.form.get('lectureNotesInput2')
    print(assno)
    driver.get("https://lms.bahria.edu.pk/Student/Dashboard.php")
    if select2 == "Course Outline":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[2]").click()
        outline = request.form.get('courseOutlineDropdown')
        print(outline)
        if outline == "Data Structures and Algorithms":
            driver.find_element(By.XPATH,
                                "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[6]/td[3]/a").click()
        if outline == "Data Structures and Algorithms Lab":
            driver.find_element(By.XPATH,
                                "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[7]/td[3]/a").click()
        if outline == "Multivariable Calculus":
            driver.find_element(By.XPATH,
                                "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()
        if outline == "Computer Organization & Assembly Language":
            driver.find_element(By.XPATH,
                                "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()
        if outline == "Computer Organization & Assembly Language Lab":
            driver.find_element(By.XPATH,
                                "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[5]/td[3]/a").click()
        if outline == "Professional Practices":
            driver.find_element(By.XPATH,
                                "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[8]/td[3]/a").click()
        if outline == "Probability and Statistics":
            driver.find_element(By.XPATH,
                                "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a").click()
    if select2 == "Course Plan":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[3]").click()
        plan = request.form.get('coursePlanDropdown')
        print(plan)
        time.sleep(3)
        driver.find_element(By.XPATH, "//*[@id='courseId']").click()
        if plan == "Multivariable Calculus":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()  # check this will work or not
            for th in range(1, 4):
                th = driver.find_element(By.XPATH,
                                         "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[1]/th[" + str(
                                             th) + "]").text
                print(th)
            for td in range(1, 4):
                tb = driver.find_element(By.XPATH,
                                         "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[" + str(
                                             td) + "]").text
                print(tb)
        if plan == "Probability and Statistics":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[2]").click()
            for th in range(1, 4):
                th = driver.find_element(By.XPATH,
                                         "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[1]/th[" + str(
                                             th) + "]").text
                print(th)
            for tr in range(2, 5):
                for td in range(1, 4):
                    tb = driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr"
                                                       "[" + str(tr) + "]/td[" + str(td) + "]").text
                    print(tb)
        if plan == "Computer Organization & Assembly Language":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[4]").click()
            th = driver.find_element(By.XPATH,
                                     "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td").text
            print(th)
        if plan == "Computer Organization & Assembly Language Lab":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[5]").click()
            for th in range(1, 4):
                thead = driver.find_element(By.XPATH,
                                            "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[1]/th[" + str(
                                                th) + "]").text
                print(thead)
            for tr in range(2, 16):
                for td in range(1, 3):
                    tdata = driver.find_element(By.XPATH,
                                                "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[" + str(
                                                    tr) + "]/td[" + str(td) + "]").text
                    print(tdata)
        if plan == "Data Structures and Algorithms":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[6]").click()
            for th in range(1, 4):
                thead = driver.find_element(By.XPATH,
                                            "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[1]/th[" + str(
                                                th) + "]").text
                print(thead)
            for tr in range(2, 18):
                for tc in range(1, 4):
                    tbody = driver.find_element(By.XPATH,
                                                "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[" + str(
                                                    tr) + "]/td[" + str(tc) + "]").text
                    print(tbody)
        if plan == "Data Structures and Algorithms Lab":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[7]").click()
            text1 = driver.find_element(By.XPATH,
                                        "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td").text
            print(text1)
        if plan == "Professional Practices":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[8]").click()
            for th in range(1, 4):
                thead = driver.find_element(By.XPATH,
                                            "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[1]/th[" + str(
                                                th) + "]").text
                print(thead)
            for tb in range(1, 4):
                tbody = driver.find_element(By.XPATH,
                                            "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[" + str(
                                                tb) + "]").text
                print(tbody)

    ##  HERE WE CAN GETTING ERROR FOR DOWNLOADING 2 LECTURES IN THE SAME PORT


    if select2 == "Lecture Notes":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[4]").click()
        driver.find_element(By.XPATH, "//*[@id='courseId']").click()
        plan = request.form.get('lectureNotesDropdown')
        print(plan)
        if plan == "Multivariable Calculus":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
            if lectnote == "1" or lectnote == "one" or lectnote == "all":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/div/div"
                                              "/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if lectnote == "2" or lectnote == "two":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/"
                                              "div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if lectnote == "3" or lectnote == "three" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if lectnote == "4" or lectnote == "four" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[5]/td[3]/a").click()

            if lectnote == "5" or lectnote == "five" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[6]/td[3]/a").click()

            if lectnote == "6" or lectnote == "six" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[7]/td[3]/a").click()

            if lectnote == "7" or lectnote == "seven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[8]/td[3]/a").click()

            if lectnote == "8" or lectnote == "eight" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[9]/td[3]/a").click()

            if lectnote == "9" or lectnote == "nine" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[10]/td[3]/a").click()

            if lectnote == "10" or lectnote == "ten" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[11]/td[3]/a").click()

            if lectnote == "11" or lectnote == "eleven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[12]/td[3]/a").click()

        if plan == "Probability and Statistics":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[2]").click()
            if lectnote == "1" or lectnote == "one" or lectnote == "all":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/div/div"
                                              "/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if lectnote == "2" or lectnote == "two":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/"
                                              "div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if lectnote == "3" or lectnote == "three" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if lectnote == "4" or lectnote == "four" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[5]/td[3]/a").click()

            if lectnote == "5" or lectnote == "five" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[6]/td[3]/a").click()

            if lectnote == "6" or lectnote == "six" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[7]/td[3]/a").click()

            if lectnote == "7" or lectnote == "seven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[8]/td[3]/a").click()

            if lectnote == "8" or lectnote == "eight" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[9]/td[3]/a").click()

            if lectnote == "9" or lectnote == "nine" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[10]/td[3]/a").click()

            if lectnote == "10" or lectnote == "ten" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[11]/td[3]/a").click()

            if lectnote == "11" or lectnote == "eleven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[12]/td[3]/a").click()
        if plan == "Computer Organization & Assembly Language":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[4]").click()
            if lectnote == "1" or lectnote == "one" or lectnote == "all":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/div/div"
                                              "/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if lectnote == "2" or lectnote == "two":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/"
                                              "div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if lectnote == "3" or lectnote == "three" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if lectnote == "4" or lectnote == "four" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[5]/td[3]/a").click()

            if lectnote == "5" or lectnote == "five" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[6]/td[3]/a").click()

            if lectnote == "6" or lectnote == "six" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[7]/td[3]/a").click()

            if lectnote == "7" or lectnote == "seven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[8]/td[3]/a").click()

            if lectnote == "8" or lectnote == "eight" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[9]/td[3]/a").click()

            if lectnote == "9" or lectnote == "nine" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[10]/td[3]/a").click()

            if lectnote == "10" or lectnote == "ten" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[11]/td[3]/a").click()

            if lectnote == "11" or lectnote == "eleven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[12]/td[3]/a").click()
        if plan == "Computer Organization & Assembly Language Lab":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[5]").click()
            if lectnote == "1" or lectnote == "one" or lectnote == "all":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/div/div"
                                              "/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if lectnote == "2" or lectnote == "two":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/"
                                              "div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if lectnote == "3" or lectnote == "three" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if lectnote == "4" or lectnote == "four" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[5]/td[3]/a").click()

            if lectnote == "5" or lectnote == "five" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[6]/td[3]/a").click()

            if lectnote == "6" or lectnote == "six" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[7]/td[3]/a").click()

            if lectnote == "7" or lectnote == "seven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[8]/td[3]/a").click()

            if lectnote == "8" or lectnote == "eight" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[9]/td[3]/a").click()

            if lectnote == "9" or lectnote == "nine" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[10]/td[3]/a").click()

            if lectnote == "10" or lectnote == "ten" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[11]/td[3]/a").click()

            if lectnote == "11" or lectnote == "eleven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[12]/td[3]/a").click()

        if plan == "Data Structures and Algorithms":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[6]").click()
            if lectnote == "1" or lectnote == "one" or lectnote == "all":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/div/div"
                                              "/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if lectnote == "2" or lectnote == "two":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/"
                                              "div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if lectnote == "3" or lectnote == "three" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if lectnote == "4" or lectnote == "four" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[5]/td[3]/a").click()

            if lectnote == "5" or lectnote == "five" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[6]/td[3]/a").click()

            if lectnote == "6" or lectnote == "six" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[7]/td[3]/a").click()

            if lectnote == "7" or lectnote == "seven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[8]/td[3]/a").click()

            if lectnote == "8" or lectnote == "eight" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[9]/td[3]/a").click()

            if lectnote == "9" or lectnote == "nine" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[10]/td[3]/a").click()

            if lectnote == "10" or lectnote == "ten" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[11]/td[3]/a").click()

            if lectnote == "11" or lectnote == "eleven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[12]/td[3]/a").click()

        if plan == "Data Structures and Algorithms Lab":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[7]").click()
            if lectnote == "1" or lectnote == "one" or lectnote == "all":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/div/div"
                                              "/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if lectnote == "2" or lectnote == "two":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/"
                                              "div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if lectnote == "3" or lectnote == "three" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if lectnote == "4" or lectnote == "four" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[5]/td[3]/a").click()

            if lectnote == "5" or lectnote == "five" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[6]/td[3]/a").click()

            if lectnote == "6" or lectnote == "six" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[7]/td[3]/a").click()

            if lectnote == "7" or lectnote == "seven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[8]/td[3]/a").click()

            if lectnote == "8" or lectnote == "eight" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[9]/td[3]/a").click()

            if lectnote == "9" or lectnote == "nine" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[10]/td[3]/a").click()

            if lectnote == "10" or lectnote == "ten" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[11]/td[3]/a").click()

            if lectnote == "11" or lectnote == "eleven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[12]/td[3]/a").click()

        if plan == "Professional Practices":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[8]").click()
            if lectnote == "1" or lectnote == "one" or lectnote == "all":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/div/div"
                                              "/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if lectnote == "2" or lectnote == "two":
                driver.find_element(By.XPATH, "/html/body/div/div/section[2]/div/"
                                              "div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if lectnote == "3" or lectnote == "three" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if lectnote == "4" or lectnote == "four" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[5]/td[3]/a").click()

            if lectnote == "5" or lectnote == "five" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[6]/td[3]/a").click()

            if lectnote == "6" or lectnote == "six" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[7]/td[3]/a").click()

            if lectnote == "7" or lectnote == "seven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[8]/td[3]/a").click()

            if lectnote == "8" or lectnote == "eight" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[9]/td[3]/a").click()

            if lectnote == "9" or lectnote == "nine" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[10]/td[3]/a").click()

            if lectnote == "10" or lectnote == "ten" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[11]/td[3]/a").click()

            if lectnote == "11" or lectnote == "eleven" or lectnote == "all":
                driver.find_element(By.XPATH,
                                    "/html/body/div/div/section[2]/div/div/div/div[2]/table/tbody/tr[12]/td[3]/a").click()

    if select2 == "Assignments":

        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[5]").click()
        driver.find_element(By.XPATH, "//*[@id='courseId']").click()
        plan = request.form.get('lectureNotesDropdown')
        print(plan)
        asno=request.form.get('lectureNotesInput3')
        print(asno)
        if plan == "Multivariable Calculus":
            if asno == "1" or asno == "one":
                driver.find_element(By.XPATH,"/html/body/div/div[1]"
                                             "/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if asno == "2" or asno == "two":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if asno == "3" or asno == "three":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if asno == "4" or asno == "four":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()
            if assno=="1" or assno=="one":

                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno=="2" or assno=="two":

                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno=="3" or assno=="three":

                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno=="4" or assno=="four":

                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()



        if plan == "Probability and Statistics":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[2]").click()

            if asno == "1" or asno == "one":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if asno == "2" or asno == "two":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if asno == "3" or asno == "three":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if asno == "4" or asno == "four":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()
            if assno == "1" or assno == "one":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "2" or assno == "two":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "3" or assno == "three":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "4" or assno == "four":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()

        if plan == "Computer Organization & Assembly Language":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[4]").click()

            if asno == "1" or asno == "one":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if asno == "2" or asno == "two":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if asno == "3" or asno == "three":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if asno == "4" or asno == "four":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if assno == "1" or assno == "one":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "2" or assno == "two":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()

                if asno == "1" or asno == "one":
                    driver.find_element(By.XPATH, "/html/body/div/div"
                                                  "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a").click()

                if asno == "2" or asno == "two":
                    driver.find_element(By.XPATH, "/html/body/div/div"
                                                  "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

                if asno == "3" or asno == "three":
                    driver.find_element(By.XPATH, "/html/body/div/div"
                                                  "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

                if asno == "4" or asno == "four":
                    driver.find_element(By.XPATH, "/html/body/div/div"
                                                  "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "3" or assno == "three":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "4" or assno == "four":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()

        if plan == "Computer Organization & Assembly Language Lab":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[5]").click()

            if asno == "1" or asno == "one":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if asno == "2" or asno == "two":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if asno == "3" or asno == "three":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if asno == "4" or asno == "four":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()
            if assno == "1" or assno == "one":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "2" or assno == "two":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "3" or assno == "three":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "4" or assno == "four":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()

        if plan == "Data Structures and Algorithms":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[6]").click()

            if asno == "1" or asno == "one":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if asno == "2" or asno == "two":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if asno == "3" or asno == "three":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if asno == "4" or asno == "four":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()
            if assno == "1" or assno == "one":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "2" or assno == "two":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "3" or assno == "three":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "4" or assno == "four":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()

        if plan == "Data Structures and Algorithms Lab":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[7]").click()

            if asno == "1" or asno == "one":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if asno == "2" or asno == "two":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if asno == "3" or asno == "three":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if asno == "4" or asno == "four":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()
            if assno == "1" or assno == "one":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "2" or assno == "two":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "3" or assno == "three":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "4" or assno == "four":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()

        if plan == "Professional Practices":
            driver.find_element(By.XPATH, "//*[@id='courseId']/option[8]").click()

            if asno == "1" or asno == "one":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[3]/a").click()

            if asno == "2" or asno == "two":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[3]/td[3]/a").click()

            if asno == "3" or asno == "three":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if asno == "4" or asno == "four":
                driver.find_element(By.XPATH,"/html/body/div/div"
                                             "[1]/section[2]/div/div/div/div[2]/table/tbody/tr[4]/td[3]/a").click()

            if assno == "1" or assno == "one":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "2" or assno == "two":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "3" or assno == "three":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()
            if assno == "4" or assno == "four":
                driver.find_element(By.XPATH, "//*[@id='courseId']/option[3]").click()
                driver.find_element(By.XPATH,
                                    "/html/body/div/div[1]/section[2]/div/div/div/div[2]/table/tbody/tr[2]/td[7]/a").click()
                time.sleep(2)
                driver.find_element(By.ID, "exampleInputFile").send_keys(assesment)
                driver.find_element(By.XPATH,
                                    "//*[@id='modal-assignment-solution-1']/div/div/form/div/div[3]/button[2]").click()

    if select2 == "Quizess":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[6]/a").click()
        quiz = request.form.get('quizzesDropdown')
        print(quiz)
    if select2 == "Miscellaneous":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[7]/a").click()
        misc = request.form.get('miscellaneousDropdown')
        print(misc)
    if select2 == "Papers":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[8]/a").click()
        papers = request.form.get('papersDropdown')
        print(papers)
    if select2 == "Announcements":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[9]").click()
        anno = request.form.get('announcementsDropdown')
        print(anno)
    if select2 == "Guidelines":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[10]").click()
        guide = request.form.get('guidelinesDropdown')
        print(guide)
    if select2 == "Online Library Resources":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[11]").click()
        library = request.form.get('onlineLibraryResourcesDropdown')
        print(library)
    if select2 == "FAQs":
        driver.find_element(By.XPATH, "/html/body/div/aside/section/ul/li[12]").click()
        FAQ = request.form.get('faqsDropdown')
        print(FAQ)
    return render_template("next1.html")


app.run(debug=True, port=5001)
driver.close()
driver.quit()
